package com.dh.SessionBookingSystem.entity;

public enum UsuarioRole {
    ROLE_USER, ROLE_ADMIN
}
