package com.dh.SessionBookingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
