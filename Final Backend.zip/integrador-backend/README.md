# Creation of Software for booking appointments in a dental clinic.

Appointment booking system for a dental clinic.

Project made for Backend I by Cindy Da Silva 

-Java 

-Spring Boot Framework

-Maven 

-JUnit 

-Hibernate(JPA)

-RESTful API Design 

We want to implement a system to manage the booking of appointments for a dental clinic. Which must meet the following requirements:
Register of dentists: last name, first name and registration number.
Dentist data management: list, add, modify and delete dentists.
Patient data management: list, add, modify and delete patients.
For each patient, the following are stored: name, surname, address, identity document and date of discharge.
Record Appointment: It must be possible to assign a patient an appointment with a dentist at a certain date and time.
Login: validate the entry to the system by means of a login with username and password.
Any user who is logged in (ROLE_USER) should be able to book an appointment, but only those with an administrator role (ROLE_ADMIN) should be able to manage dentists and patients.
A user can only have one role and it will be entered directly into the database.

# Technical requirements

The application must be developed in layers:

- Business entity layer: they are the Java classes of our business modeled through the object-oriented paradigm.
- Data access layer (Repository): these are the classes that will be in charge of accessing the database.
- Data layer (database): it is the database of our modeled system through an entity-relationship model.
  We will use the H2 base for its practicality.
- Business layer: they are the service classes that are in charge of decoupling the access to the data from the view.
- Presentation layer: these are the web screens that we will have to develop using the Spring Boot MVC framework with the controllers and one of these two options: HTML+JavaScript or React for the view.

It is important to perform exception handling by logging any exception that may be generated and performing unit tests to ensure the quality of developments.
